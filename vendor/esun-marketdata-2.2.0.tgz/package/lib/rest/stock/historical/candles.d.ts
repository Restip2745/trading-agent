import { RestClientRequest } from '../../client';
export interface RestStockHistoricalCandlesParams {
    symbol: string;
    from?: string;
    to?: string;
    timeframe?: 'D' | 'W' | 'M' | '1' | '3' | '5' | '10' | '15' | '30' | '60';
    fields?: string;
    sort?: 'asc' | 'desc';
}
export interface RestStockHistoricalCandlesResponse {
    symbol: string;
    type: string;
    exchange: string;
    market: string;
    timeframe: string;
    data: Array<{
        date: string;
        open: number;
        high: number;
        low: number;
        close: number;
        volume: number;
        turnover: number;
        change: number;
    }>;
}
export declare const candles: (request: RestClientRequest, params: RestStockHistoricalCandlesParams) => Promise<RestStockHistoricalCandlesResponse>;
