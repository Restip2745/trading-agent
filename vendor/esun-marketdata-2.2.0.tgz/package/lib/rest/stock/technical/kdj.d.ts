import { RestClientRequest } from '../../client';
export interface RestStockTechnicalKdjParams {
    symbol: string;
    from?: string;
    to?: string;
    timeframe?: 'D' | 'W' | 'M' | '1' | '3' | '5' | '10' | '15' | '30' | '60';
    rPeriod: number;
    kPeriod: number;
    dPeriod: number;
}
export interface RestStockTechnicalKdjResponse {
    symbol: string;
    type: string;
    exchange: string;
    market: string;
    timeframe: string;
    data: Array<{
        date: string;
        k: number;
        d: number;
        j: number;
    }>;
}
export declare const kdj: (request: RestClientRequest, params: RestStockTechnicalKdjParams) => Promise<RestStockTechnicalKdjResponse>;
