export interface ParsedRealtimeToken {
    expiresAt: string;
    token: string;
}
