import { ClientConfig } from './client-config.interface';
export interface EsunMarketdataOptions {
    configPath?: string;
    config?: Partial<ClientConfig>;
}
