export declare enum Side {
    Buy = "B",
    Sell = "S"
}
