export declare enum TradeType {
    Cash = "0",
    Margin = "3",
    Short = "4",
    DayTradingSell = "A"
}
