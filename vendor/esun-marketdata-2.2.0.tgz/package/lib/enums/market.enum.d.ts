export declare enum Market {
    All = "0",
    TSE = "1",
    OTC = "2",
    EMG = "3"
}
