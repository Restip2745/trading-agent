export declare enum MessageKind {
    ACK = "ACK",
    MAT = "MAT"
}
