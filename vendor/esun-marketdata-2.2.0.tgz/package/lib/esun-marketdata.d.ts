import { EsunMarketdataOptions } from "./interfaces";
import { Client } from "./client";
export declare class EsunMarketdata extends Client {
    constructor(options?: EsunMarketdataOptions);
}
