/// <reference types="node" />
import * as events from 'events';
export interface WebSocketClientOptions {
    url: string;
    apiKey?: string;
    bearerToken?: string;
    sdkToken?: string;
}
export declare class WebSocketClient extends events.EventEmitter {
    protected readonly options: WebSocketClientOptions;
    private socket;
    constructor(options: WebSocketClientOptions);
    connect(): Promise<unknown>;
    disconnect(): void;
    subscribe(params: {
        channel: string;
        [key: string]: any;
    }): void;
    unsubscribe(params: {
        id?: string;
        ids?: string[];
    }): void;
    ping(params: {
        state?: any;
    }): void;
    subscriptions(): void;
    private authenticate;
    private send;
    private handleMessage;
}
