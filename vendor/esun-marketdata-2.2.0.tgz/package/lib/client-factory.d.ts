export interface ClientOptions {
    baseUrl: string;
    apiKey?: string;
    bearerToken?: string;
    sdkToken?: string;
}
export declare abstract class ClientFactory {
    protected readonly options: ClientOptions;
    constructor(options: ClientOptions);
}
