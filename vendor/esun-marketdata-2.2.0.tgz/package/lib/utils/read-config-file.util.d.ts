import { ClientConfig } from '../interfaces';
export declare function readConfigFile(path: string): Partial<ClientConfig>;
