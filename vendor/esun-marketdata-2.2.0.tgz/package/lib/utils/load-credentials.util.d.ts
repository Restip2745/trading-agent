import { Credentials } from '../interfaces';
export declare function loadCredentials(account: string): Promise<Credentials>;
