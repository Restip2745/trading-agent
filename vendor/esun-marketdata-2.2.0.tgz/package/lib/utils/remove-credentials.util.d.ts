export declare function removeCredentials(account: string): Promise<void>;
