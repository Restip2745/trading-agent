import { CoreSdk } from "@esun/trade-core";
import { ClientConfig } from "./interfaces/client-config.interface";
import { RestClientFactory } from "./rest";
import { WebSocketClientFactory } from "./websocket";
declare const SDK: unique symbol;
export declare class Client {
    private readonly config;
    private [SDK];
    private sdkToken?;
    constructor(config: ClientConfig);
    get sdk(): CoreSdk;
    set sdk(sdk: CoreSdk);
    get restClient(): RestClientFactory;
    get websocketClient(): WebSocketClientFactory;
    login(): Promise<void>;
    logout(): Promise<void>;
    getMarketdataRestUrl(): string;
    getMarketdataWsUrl(): string;
    getSdkToken(): Promise<string>;
}
export {};
